package zuul.commands;

import zuul.GameStatus;
import zuul.items.Item;
import zuul.items.HiddenItem;

public class Examine extends Command {

    public Examine(String parameter) {
        super(parameter);
    }

    public String commandImplementation(GameStatus gameStatus) {
        if (!hasParameter()) {
            return "What do you want to examine?";
        }

        String itemName = getParameter();
        Item item = gameStatus.getLocation().getItem(itemName);

        if (item == null) {
            item = gameStatus.getInventory().get(itemName);
            if (item == null) {
                return "There is no item with that name.";
            }
        }

        // إذا كان العنصر مخفي (HiddenItem)، نفعّل خاصية الفحص
        if (item instanceof HiddenItem) {
            item.setExamined(true);  // نفعّل فحص العنصر المخفي
        }

        // إرجاع الوصف إذا تم فحص العنصر
        return item.getDescription();
    }
}
