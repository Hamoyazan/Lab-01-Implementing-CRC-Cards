package zuul.items;

/**
 * هذا الكلاس يمثل عنصر مخفي يظهر فقط بعد فحصه (examine).
 */
public class HiddenItem extends Item {

    /**
     * ينشئ عنصر مخفي، يكون غير مفحوص افتراضياً (مخفي).
     */
    public HiddenItem(String name, String description, int weight) {
        super(name, description, weight);
        setExamined(false); // مخفي بالبداية
    }

    /**
     * هل العنصر مخفي؟ يتم تحديد ذلك حسب ما إذا تم فحصه أو لا.
     */
    public boolean isHidden() {
        return !isExamined();
    }

    /**
     * نستخدمها للتحكم بإظهار العنصر أو إخفائه يدوياً.
     */
    public void setHidden(boolean hidden) {
        setExamined(!hidden); // إذا طلبنا إخفاء العنصر، نخلي examined = false
    }
}
