package zuul.commands;

import org.junit.jupiter.api.Test;
import zuul.Game;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BeamerTest {
    Game game;
    public BeamerTest()
    {
        game = new Game("test/data/zuul.yml");
    }



    @Test
    public void testBeamer(){
        String result = game.processCommand("go south");
        result = game.processCommand("beamer charge");
        result = game.processCommand("go north");
        result = game.processCommand("beamer fire");
        result = game.processCommand("look");
        assertTrue(result.contains("in a computing lab"), "should be back in computing lab");
    }
}
