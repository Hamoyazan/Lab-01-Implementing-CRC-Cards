package zuul;

import static org.junit.jupiter.api.Assertions.*;

class RoomTest {

}