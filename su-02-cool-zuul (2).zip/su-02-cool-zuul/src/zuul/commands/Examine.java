package zuul.commands;

import zuul.GameStatus;
import zuul.items.Item;

public class Examine extends Command {

    public Examine(String parameter) {
        super(parameter);
    }


    public String commandImplementation(GameStatus gameStatus) {
        if (!hasParameter()) {
            return "What do you want to examine?";
        }

        String itemName = getParameter();

        Item item = gameStatus.getLocation().getItem(itemName, true);

        if (item == null) {
            item = gameStatus.getInventory().get(itemName);
            if (item == null) {
                return "there is no item with that name";
            }
        }

        return item.getDescription();
    }
}
