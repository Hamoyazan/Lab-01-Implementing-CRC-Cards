package zuul.items;

public class HiddenItem extends Item {
    boolean hidden;

    public boolean isHidden() {
        return hidden;
    }

    public HiddenItem(String name, String description, int weight) {
        super(name, description, weight);
        this.hidden = hidden;
    }


}
