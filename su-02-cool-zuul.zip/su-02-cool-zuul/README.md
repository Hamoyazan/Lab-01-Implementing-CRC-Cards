# CoolZuul

This is an IntelliJ Adaption and Extension of the Zuul Project.

This first version contains most of the exercises of the book,
like picking up Items and carrying them around.
The world is read from a yml file.

The original Zuul project was created by Michael Kölling and David J. Barnes
as  part of the material for the book
Objects First with Java - A Practical Introduction using BlueJ
Sixth edition, David J. Barnes and Michael Kölling, Pearson Education, 2016

## Start Game

There is a main method in zuul.Start which can be used from within the IDE
or (after the Project was built by the IDE) from the command line:


    java -cp "out/production/su-02-cool-zuul:lib/*" zuul.Start

## Run Tests from Console

### 1. Download junit-platform-console-standalone-1.9.3.jar
you need to download the standalone jar from maven (.gitignored as it is pretty large):

junit-platform-console-standalone-1.9.3.jar

>du -hs junit-platform-console-standalone-1.9.3.jar
2,5M	junit-platform-console-standalone-1.9.3.jar

see: 
https://junit.org/junit5/docs/current/user-guide/#running-tests-console-launcher

direct maven link:
https://repo1.maven.org/maven2/org/junit/platform/junit-platform-console-standalone/1.9.3/

### 2. Run all tests 

    java -jar junit-platform-console-standalone-1.9.3.jar \
        --class-path "out/production/su-02-cool-zuul:out/test/su-02-cool-zuul:lib/snakeyaml-2.4.jar" \
        --scan-class-path






## Dependencies

### SnakeYaml 2.4

- Documentation: https://bitbucket.org/snakeyaml/snakeyaml/wiki/Documentation
- Home Page: https://bitbucket.org/snakeyaml/snakeyaml
- API Documentation: https://javadoc.io/doc/org.yaml/snakeyaml/latest/org/yaml/snakeyaml/Yaml.html


## Links

Created for [Info2 Lab Assignments](https://home.htw-berlin.de/~kleinen/classes/ws2021/info2/labs/).

## Notes
## Monday, 07.April 2025
Updated for Summer 25, snakeyaml 1.9-> 2.4 required an adaption:
https://bitbucket.org/snakeyaml/snakeyaml/wiki/Documentation#markdown-header-providing-the-top-level-type

